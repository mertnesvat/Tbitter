<?php
$consumer_key = '<PLACE YOUR CONSUMER KEY HERE>';
$consumer_secret = '<PLACE YOUR CONSUMER SECRET KEY HERE>';
?>